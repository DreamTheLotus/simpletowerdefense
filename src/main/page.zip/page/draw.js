var table = document.querySelector("#table")
const $VW = document.documentElement.clientWidth
const $10VW = $VW * 0.1
const $mapVW = $VW * 0.5
const $10mapVW = $mapVW * 0.1
table.innerHTML = '<canvas id="map" width="' + $mapVW + 'px" height="' + $mapVW + 'px"></canvas>'
var map = document.querySelector("#map")
var pen = map.getContext("2d");
var gun = new Image()
gun.src = "image/artillery-pedestal.png"
var route = new Array()

var tile = function() {
	var x = 0
	var y = 0
	this.setX = function(data) {
		x = data
	}
	this.setY = function(data) {
		y = data
	}
	this.getX = function() {
		return x
	}
	this.getY = function() {
		return y
	}
	this.push = function(dataX, dataY) {
		x = dataX
		y = dataY
	}
}

var main = new tile()

main.push(8,2)
route.push(main)
main.push(3,6)
route.push(main)
for (let data of route) {
	console.log("数组：(" + data.getX() + "," + data.getY() + ")")
}

var game_map = [
	[8, 0, 0, 0, 0, 0, 0, 0, 0, 0],
	[7, 0, 0, 0, 0, 0, 7, 7, 7, 0],
	[7, 7, 7, 0, 0, 0, 7, 0, 7, 7],
	[0, 0, 7, 0, 0, 7, 7, 0, 0, 7],
	[7, 7, 7, 0, 0, 7, 0, 0, 7, 7],
	[7, 0, 0, 0, 7, 7, 0, 0, 7, 0],
	[7, 0, 0, 7, 7, 0, 0, 7, 7, 0],
	[7, 0, 0, 7, 0, 0, 0, 7, 0, 0],
	[7, 7, 7, 7, 0, 0, 0, 7, 0, 0],
	[0, 0, 0, 0, 0, 0, 0, 7, 7, 9]
]
//pen.drawImage(gun, 0, 0, $10mapVW, $10mapVW)

draw_table()

function draw_table() {
	for (let i = 0; i <= 10; i++) {
		vertical(i)
		horizontal(i)
	}
	draw_route()
	//build_route()
}

function vertical(i) {
	pen.beginPath()
	pen.lineWidth = 2
	pen.moveTo(i * $10mapVW, 0)
	pen.lineTo(i * $10mapVW, $mapVW)
	pen.strokeStyle = "#a0a0a0"
	pen.stroke()
}

function horizontal(i) {
	pen.beginPath()
	pen.lineWidth = 2
	pen.moveTo(0, i * $10mapVW)
	pen.lineTo($mapVW, i * $10mapVW)
	pen.strokeStyle = "#a0a0a0"
	pen.stroke()
}

function draw_route() {
	for (let x = 0; x < game_map.length; x++) {
		for (let y = 0; y < game_map[x].length; y++) {
			switch (game_map[x][y]) {
				case 7:
					table_style_7(y, x)
					break
				case 8:
					main.push(y, x)
					table_style_8(y, x)
					break
				case 9:
					table_style_9(y, x)
					break
			}
		}
	}
}

function table_style_9(x, y) {
	pen.beginPath();
	pen.arc((x + 0.5) * $10mapVW, (y + 0.5) * $10mapVW, 0.35 * $10mapVW, 0, 360, false);
	pen.lineWidth = 2
	pen.strokeStyle = "#a0a0a0";
	pen.stroke(); //画空心圆
}

function table_style_8(x, y) {
	pen.beginPath()
	pen.lineWidth = 2
	pen.moveTo((x + 0.1) * $10mapVW, (y + 0.1) * $10mapVW)
	pen.lineTo((x + 0.9) * $10mapVW, (y + 0.9) * $10mapVW)
	pen.strokeStyle = "#a0a0a0"
	pen.stroke()

	pen.beginPath()
	pen.lineWidth = 2
	pen.moveTo((x + 0.1) * $10mapVW, (y + 0.9) * $10mapVW)
	pen.lineTo((x + 0.9) * $10mapVW, (y + 0.1) * $10mapVW)
	pen.strokeStyle = "#a0a0a0"
	pen.stroke()
}

function table_style_7(x, y) {
	pen.beginPath()
	pen.lineWidth = 2
	pen.moveTo((x + 0.1) * $10mapVW, (y + 0.1) * $10mapVW)
	pen.lineTo((x + 0.9) * $10mapVW, (y + 0.1) * $10mapVW)
	pen.lineTo((x + 0.9) * $10mapVW, (y + 0.9) * $10mapVW)
	pen.lineTo((x + 0.1) * $10mapVW, (y + 0.9) * $10mapVW)
	pen.fillStyle = "#a0a0a0"
	pen.fill()
}

function build_route() {
	var i = 0
	var nowX = 0
	var nowY = 0
	var nextX = 0
	var nextY = 0
	var end = false
	var next = false
	var error = true
	//直到路径扫描完毕结束
	while (true) {

		for (let i = 0; i < route.length; i++) {
			console.log("数组：(" + route[i].getX() + "," + route[i].getY() + ")"+i)
		}


		nowX = main.getX()
		nowY = main.getY()
		var check_data
		for (let i = 0; i < 4; i++) {
			check_data = eval("check_" + i + "(" + main.getX() + "," + main.getY() + ")")
			if (check_data != "error") {
				//TODO 作为next的检测
				for (let i = 0; i < route.length; i++) {
					console.log("(" + route[i].getX() + "," + route[i].getY() + ")--(" + nextX + "," + nextY + ")")
					if (route[i].getX() == nextX && route[i].getY() == nextY) {
						next = false
					}
				}
				next = true
			}
			if (check_data != "error" && next) {
				break
			}
		}
		if (check_data != "error") {
			nextX = check_data.split("-")[0]
			nextY = check_data.split("-")[1]
			if (check_data.split("-")[2] == 0) {
				end = false
			} else {
				end = true
			}
			error = false
		} else {
			error = true
		}
		console.log(nowX + "," + nowY + "," + error)
		//检查历史路径坐标是否重复

		if (next && !error) {
			main.push(nextX, nextY)
			route.add(main)
		}
		i++
		if (i == 10) {
			console.log(i)
			break
		}
		if (end) {
			console.log(end)
			break
		}
	}
}

function check_0(nowX, nowY) {
	if (nowY - 1 > 0) {
		if (game_map[nowX][nowY - 1] == 7) {
			return nowX + "-" + nowY - 1 + "-" + 0
		} else if (game_map[nowX][nowY - 1] == 8) {
			return nowX + "-" + nowY - 1 + "-" + 1
		}
		return "error"
	}
	return "error"
}

function check_2(nowX, nowY) {
	if (nowY + 1 < game_map[0].length) {
		if (game_map[nowX][nowY + 1] == 7) {
			return nowX + "-" + nowY + 1 + "-" + 0
		} else if (game_map[nowX][nowY + 1] == 8) {
			return nowX + "-" + nowY + 1 + "-" + 1
		}
		return "error"
	}
	return "error"
}

function check_1(nowX, nowY) {
	if (nowX - 1 > 0) {
		if (game_map[nowX - 1][nowY] == 7) {
			return nowX - 1 + "-" + nowY + "-" + 0
		} else if (game_map[nowX - 1][nowY] == 8) {
			return nowX - 1 + "-" + nowY + "-" + 1
		}
		return "error"
	}
	return "error"
}

function check_3(nowX, nowY) {
	if (nowX + 1 < game_map[0].length) {
		if (game_map[nowX + 1][nowY] == 7) {
			return nowX + 1 + "-" + nowY + "-" + 0
		} else if (game_map[nowX + 1][nowY] == 8) {
			return nowX + 1 + "-" + nowY + "-" + 1
		}
		return "error"
	}
	return "error"
}
