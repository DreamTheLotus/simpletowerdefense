var message = document.querySelector("#message")
var jump = document.querySelector("#jump")
//sendMessage()
//sendCustom()
function sendMessage() {
	// 这里的 method 就是 client 创建 CefMessageRouter 对象的入参涉及到的字符串
	window.method({
		request: 'click:一些信息',
		onSuccess(response) {
			console.log(response);
		},
		onFailure(error_code, error_message) {
			console.log(error_code, error_message);
		}
	});
	window.method({
		request: 'custom: connect-192.168.1.1',
		onSuccess(response) {
			console.log(response);
		},
		onFailure(error_code, error_message) {
			console.log(error_code, error_message);
		}
	});
	window.method({
		request: 'custom: search-' + JSON.stringify({
			a: 1,
			b: "str"
		}),
		onSuccess(response) {
			console.log(response);
		},
		onFailure(error_code, error_message) {
			console.log(error_code, error_message);
		}
	});
}
jump.onclick = function() {
	/* console.log("需要传递信息")
	window.method({
		request: "jump: www.bing.com",
		onSuccess(response) {
			console.log(response);
		},
		onFailure(error_code, error_message) {
			console.log(error_code, error_message);
		}
	}); */
}

/* table.style.display = "inline-block"
table.style.width = window.screen.width*0.3+"px"
table.style.height = window.screen.width*0.3+"px"
table.style.background = "red"
table.innerHTML = "..." */
